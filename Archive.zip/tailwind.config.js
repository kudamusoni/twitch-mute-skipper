/** @type {import('tailwindcss').Config} */
module.exports = {
  content: [
    "./popup.html",
  ],
  theme: {
    extend: {},
  },
  plugins: [],
}

